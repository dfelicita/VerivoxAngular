import { ShortNumberPipe } from './short-number.pipe';

describe('ShortNumberPipe', () => {
  it('create an instance', () => {
    const pipe = new ShortNumberPipe();
    expect(pipe).toBeTruthy();
  });
});
